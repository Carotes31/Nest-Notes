const CACHE = 'nestnotes-v2'; // Changement de version pour forcer le refresh
const FILES = ['/index.html', '/manifest.json', '/icon-192.png', '/icon-512.png'];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(FILES))
  );
  self.skipWaiting(); // Forcer l'activation immédiate du nouveau SW
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    )
  );
  self.clients.claim(); // Prendre le contrôle des clients immédiatement
});

self.addEventListener('fetch', e => {
  // Stratégie Network First pour le fichier HTML afin de détecter les mises à jour plus rapidement
  if (e.request.mode === 'navigate') {
    e.respondWith(
      fetch(e.request).catch(() => caches.match(e.request))
    );
    return;
  }
  
  e.respondWith(
    caches.match(e.request).then(r => r || fetch(e.request))
  );
});
